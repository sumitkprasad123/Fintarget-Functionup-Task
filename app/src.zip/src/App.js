import './App.css';
import { useState, useEffect, useRef } from 'react'
import ReactApexChart from 'react-apexcharts'
import Navbar from "./components/Navbar"



function App() {

  const [liveData, setLiveData] = useState({});
  const [minData, setMinData] = useState([]);
  const [OneMinData, setOneMinData] = useState([]);
  const [threeMinData, setThreeMinData] = useState([]);
  const [fiveMinData, setFiveMinData] = useState([]);
  const ref = useRef("Nifty")

  const options = {
    chart: {
        type: "candlestick",
    },
    title: {
        text: `${ref.current.instrument || "Nifty"} stock`,
        align: "left",
    },
    xaxis: {
        type: "datetime",
    },
    yaxis: {
        tooltip: {
            enabled: true,
        },
    },
};

  useEffect(() => {
    const socket = new WebSocket('wss://functionup.fintarget.in/ws?id=fintarget-functionup');

    socket.addEventListener('message', (event) => {
        const message = JSON.parse(event.data);
        if (typeof message === 'object') {
        //   Update WebSocket live data
          setLiveData(message);
        }
    });

    socket.addEventListener('error', (event) => {
         console.error('WebSocket error:', event);
    });

    return () => {
      // Cleanup WebSocket connection when component unmounts
       socket.close();
      };
    }, []);

   // --------------------------------------//
   const timestamp = new Date().getTime();


   useEffect(()=> {
      let mainValue = []
      mainValue.push(liveData[ref.current.instrument])
      const id = setInterval(() => {
          oneMinFn(mainValue)
        },1000)

        return () => {
          clearInterval(id)
        }
    },[timestamp])

   const oneMinFn = (mainValue) => {
    let max = -Infinity
    let min = Infinity

   for(let i=0;i<4;i++){
       if(max<mainValue[i]){
         max=mainValue[i]
       }
       if(min>mainValue[i]){
         min=mainValue[i]
       }
   }
   console.log(max,min)
    let new_data = [mainValue[0],max,min,mainValue[mainValue.length-1]]
    let obj = {
        "x":new Date(timestamp).getTime(),
        "y":new_data
     }
    setMinData([...minData,obj])
    mainValue = []
   }

   const sortInstrument = (value) => {
     ref.current = value
     console.log(ref)
   }
  return (
    <div className="App">
         <Navbar
            liveData={liveData}
            sortInstrument={sortInstrument}
          />
          <h1 style={{textAlign:"center"}}>
             Algowiz Candlestick Chart
          </h1>
         <div style={{ width: "100vh", height: "100%", margin:"auto"}}>
              <ReactApexChart
                  options={options}
                  series={
                      [{
                          "data": minData 
                      }]
                  }
                  type="candlestick"
              />
         </div>
    </div>
  );
}

export default App;
